﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;// for using IWebDriver
using OpenQA.Selenium.Chrome;// for using Chrome browser

namespace SeleniumCSharp
{
    public class CustomControl
    {
        //Select comboBox, empty it, write a value in, then select that value.
        public void ComboBox(string controlName, string value, IWebDriver Driver) {
            
            IWebElement comboControl = Driver.FindElement(By.XPath($"//input[@id='{controlName}-awed']"));
            comboControl.Clear();
            comboControl.SendKeys(value);

            Driver.FindElement(By.XPath($"//div[@id='{controlName}-dropmenu']//li[text()='{value}']")).Click();

        }

        //To send text in input
        public void EnterText(IWebElement webElement, string value)
        {
            webElement.SendKeys(value);
        }

        //To click on a element in webpage
        public void ClickElement(IWebElement webElement)
        {
            webElement.Click();
        }

    }
}
