using NUnit.Framework;
using System;
//ADD NuGet package to the projet : Selenium.chrome.webdriver AND  selenium.webdriver
//add the using for both
using OpenQA.Selenium;// for using IWebDriver
using OpenQA.Selenium.Chrome;// for using Chrome browser
//
//If you would wish to use another browser it'll would be like so:
//using OpenQA.Selenium.Edge; // if using Edge Brower
//using OpenQA.Selenium.Firefox; // if using FireFox Brower


namespace SeleniumCSharp
{
    public class Tests
    {
        IWebDriver Driver;

        [SetUp]
        public void Setup()
        {
            /*
            I've had issue with this part since i do not have env variable for my driver on my pc. Thus, i had to download the driver on my pc and link it
            as a string in my project to open the browser.
            */
            //specify the path of my driver
            string myPath = "C:\\Users\\Joannie\\Downloads\\chromedriver_win32";
            
            //set my Driver to open a new Chrome browser page in wich we put the path of my installed driver
            Driver = new ChromeDriver(myPath);

            //If you would have liked to use another browser it would have been as so:
            //Driver = new FirefoxDriver();
            //Driver = new EdgeDriver();

            Console.WriteLine("The setup is done!");
        }



        /// <summary>
        /// This test only open a url in the specified browser(driver)
        /// </summary>


        //Un-comment Test to actually test this one
        //[Test]
        public void OpenBrowser()
        {
            //This open the browers with our set Driver as above (chrome) and send it to the url in between the parenthesis.
            //Driver.Navigate().GoToUrl("https://executeautomation.com");

            Assert.Pass();
            Console.WriteLine("Look the browser has opened!");
        }
        


        /// <summary>
        /// This test only open a url in the specified browser(driver)
        /// And then fill in some input inside the page by the element id.
        /// 
        /// !!!!!! XPATH !!!!!!
        /// XPath is used programmatically to evaluate expressions and select specific nodes in a document.
        /// thus we can simply use it to find element in the dom/xml
        /// A double slash "//" means any descendant node of the current node in the HTML tree which matches the locator.
        /// A single slash "/" means a node which is a direct child of the current.
        /// A double colon :: is used to separate the axis specifier from the node test ?? this part i'll need to investigate more
        /// text() function is used to find a particular text value.
        /// folowing-sibling is the next element sibling
        /// </summary>
        //[Test]
        public void fillInput()
        {
            
            Driver.Navigate().GoToUrl("https://demowf.aspnetawesome.com");

            //find the input by it's ID  : Driver.FindElement(By.Id("ContentPlaceHolder1_Meal"))
            //Fill in the element with string : .SendKeys("sUpEr TeSt")
            Driver.FindElement(By.Id("ContentPlaceHolder1_Meal")).SendKeys("sUpEr TeSt");

            //Click on a checkbox by XPATH 
            //Find element with this XPath where the name=     ... find his sibling elements .. next sibling where his name is Celery. Click on it  
            Driver.FindElement(By.XPath("//input[@name='ctl00$ContentPlaceHolder1$ChildMeal1']/following-sibling::div[text()='Celery']")).Click();
            Driver.FindElement(By.XPath("//input[@name='ctl00$ContentPlaceHolder1$ChildMeal1']/following-sibling::div[text()='Broccoli']")).Click();
            Driver.FindElement(By.XPath("//input[@name='ctl00$ContentPlaceHolder1$ChildMeal1']/following-sibling::div[text()='Artichoke']")).Click();


            //ComboBox : select a element from the box by first clicking in dropDown arrow
            //On the element clear the default value inside
            //Driver.FindElement(By.XPath("//input[@id='ContentPlaceHolder1_AllMealsCombo-awed']")).Clear();
            IWebElement comboControl = Driver.FindElement(By.XPath("//input[@id='ContentPlaceHolder1_AllMealsCombo-awed']"));

            comboControl.Clear();
            comboControl.SendKeys("Almonds");
            //For selecting the precise element in the comboBox list we cannot use the comboControl. Rather do another search element
            Driver.FindElement(By.XPath("//div[@id='ContentPlaceHolder1_AllMealsCombo-dropmenu']//li[text()='Almonds']")).Click();

            Assert.Pass();
            
        }


        //[Test]
        public void SelectComboBox()
        {
            //Same thing we did before but using a class for our Costum Control method
            Driver.Navigate().GoToUrl("https://demowf.aspnetawesome.com");
            string controlName = "ContentPlaceHolder1_AllMealsCombo";
            string value = "Almond";

            CustomControl myTest = new CustomControl();
            myTest.ComboBox(controlName, value, Driver);
            Assert.Pass();

        }


        [Test]
        public void SelectComboBox02()
        {
            //Same thing we did before but using a class for our Costum Control method
            Driver.Navigate().GoToUrl("https://demowf.aspnetawesome.com");
            string controlName = "ContentPlaceHolder1_AllMealsCombo";
            string value = "Almond";
            CustomControl myTest = new CustomControl();



            IWebElement comboControl = Driver.FindElement(By.XPath($"//input[@id='{controlName}-awed']"));
            comboControl.Clear();

            myTest.EnterText(comboControl, value);


            //IWebElement selectElement = Driver.FindElement(By.XPath($"//div[@id='{controlName}-dropmenu']//li[text()='{value}']")).Click();




            Assert.Pass();

        }





    }
}